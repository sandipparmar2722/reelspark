import 'package:flutter/material.dart';
import 'package:reelspark/ui/editor/editor.dart';

/// Effects panel widget (CapCut-style)
///
/// Contains:
/// - Horizontal list of video effects
/// - Tap to add effect at current playhead
class EffectsPanel extends StatelessWidget {
  /// Callback when effect is added
  final Function(EffectType) onEffectAdd;

  /// Callback when panel is closed
  final VoidCallback? onClose;

  const EffectsPanel({
    super.key,
    required this.onEffectAdd,
    this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 96,
      padding: const EdgeInsets.symmetric(vertical: 8),
      color: const Color(0xFF1A1A1A),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ================= HEADER =================
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                const Text(
                  'Effects',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                if (onClose != null)
                  GestureDetector(
                    onTap: onClose,
                    child: const Icon(
                      Icons.close,
                      color: Colors.white54,
                      size: 18,
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // ================= EFFECT LIST =================
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: EffectType.values.map((type) {
                return _EffectItem(
                  label: type.name.toUpperCase(),
                  icon: _iconForEffect(type),
                  onTap: () => onEffectAdd(type),

                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  // Map effect to icon
  static IconData _iconForEffect(EffectType type) {
    switch (type) {
      case EffectType.blur:
        return Icons.blur_on;
      case EffectType.glitch:
        return Icons.broken_image;
      case EffectType.lightLeak:
        return Icons.wb_sunny;
      default:
        return Icons.auto_awesome;
    }
  }
}

/// Single effect tile
class _EffectItem extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _EffectItem({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 88,
        margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white24),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white70, size: 22),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
