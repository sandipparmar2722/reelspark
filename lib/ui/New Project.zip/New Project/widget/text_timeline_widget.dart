import '../newproject.dart';

// ui/widgets/text_timeline_widget.dart

// Minimum text clip duration in seconds
const double _kMinDuration = 0.1;

class TextTimelineWidget extends StatefulWidget {
  final List<TextClip> clips;
  final double pixelsPerSecond;
  final double totalDuration;
  final TextClip? selectedClip;
  final Function(TextClip) onSelect;
  final Function(TextClip, double, double) onTrim;
  final Function(TextClip, double, double) onMove;

  const TextTimelineWidget({
    super.key,
    required this.clips,
    required this.pixelsPerSecond,
    required this.totalDuration,
    required this.onSelect,
    required this.onTrim,
    required this.onMove,
    this.selectedClip,
  });

  @override
  State<TextTimelineWidget> createState() => _TextTimelineWidgetState();
}

class _TextTimelineWidgetState extends State<TextTimelineWidget> {
  // Track which clip is being dragged and its original times
  TextClip? _draggingClip;
  double _dragStartTime = 0;
  double _dragEndTime = 0;

  // Track trim state
  TextClip? _trimmingClip;
  double _trimOriginalStart = 0;
  double _trimOriginalEnd = 0;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: Stack(
        children: widget.clips.map((clip) {
          final left = clip.startTime * widget.pixelsPerSecond;
          final width = clip.duration * widget.pixelsPerSecond;
          final isSelected = widget.selectedClip?.id == clip.id;

          return Positioned(
            left: left,
            width: width.clamp(24.0, double.infinity), // Min width for visibility
            top: 6,
            bottom: 6,
            child: _TextClipWidget(
              clip: clip,
              isSelected: isSelected,
              pixelsPerSecond: widget.pixelsPerSecond,
              totalDuration: widget.totalDuration,
              onTap: () => widget.onSelect(clip),
              // LEFT TRIM HANDLE - adjusts startTime
              onTrimStartBegin: () {
                _trimmingClip = clip;
                _trimOriginalStart = clip.startTime;
                _trimOriginalEnd = clip.endTime;
              },
              onTrimStartUpdate: (totalDeltaPx) {
                if (_trimmingClip?.id != clip.id) return;

                final deltaSeconds = totalDeltaPx / widget.pixelsPerSecond;
                double newStart = _trimOriginalStart + deltaSeconds;

                // Clamp: newStart >= 0 AND newStart <= endTime - MIN_DURATION
                newStart = newStart.clamp(0.0, _trimOriginalEnd - _kMinDuration);

                widget.onTrim(clip, newStart, _trimOriginalEnd);
              },
              onTrimStartEnd: () {
                _trimmingClip = null;
              },
              // RIGHT TRIM HANDLE - adjusts endTime
              onTrimEndBegin: () {
                _trimmingClip = clip;
                _trimOriginalStart = clip.startTime;
                _trimOriginalEnd = clip.endTime;
              },
              onTrimEndUpdate: (totalDeltaPx) {
                if (_trimmingClip?.id != clip.id) return;

                final deltaSeconds = totalDeltaPx / widget.pixelsPerSecond;
                double newEnd = _trimOriginalEnd + deltaSeconds;

                // Clamp: newEnd >= startTime + MIN_DURATION (no upper limit - can extend)
                newEnd = newEnd.clamp(_trimOriginalStart + _kMinDuration, double.infinity);

                widget.onTrim(clip, _trimOriginalStart, newEnd);
              },
              onTrimEndEnd: () {
                _trimmingClip = null;
              },
              // MOVE (long press + drag)
              onMoveStart: () {
                setState(() {
                  _draggingClip = clip;
                  _dragStartTime = clip.startTime;
                  _dragEndTime = clip.endTime;
                });
              },
              onMoveUpdate: (deltaSeconds) {
                if (_draggingClip?.id != clip.id) return;

                final duration = _dragEndTime - _dragStartTime;
                double newStart = _dragStartTime + deltaSeconds;
                double newEnd = _dragEndTime + deltaSeconds;

                // Clamp to valid range
                if (newStart < 0) {
                  newStart = 0;
                  newEnd = duration;
                }
                if (newEnd > widget.totalDuration) {
                  newEnd = widget.totalDuration;
                  newStart = newEnd - duration;
                }

                widget.onMove(clip, newStart, newEnd);
              },
              onMoveEnd: () {
                setState(() {
                  _draggingClip = null;
                });
              },
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// Individual text clip widget with trim handles and drag-to-move
class _TextClipWidget extends StatefulWidget {
  final TextClip clip;
  final bool isSelected;
  final double pixelsPerSecond;
  final double totalDuration;
  final VoidCallback onTap;
  // Left trim handle callbacks
  final VoidCallback onTrimStartBegin;
  final Function(double totalDeltaPx) onTrimStartUpdate;
  final VoidCallback onTrimStartEnd;
  // Right trim handle callbacks
  final VoidCallback onTrimEndBegin;
  final Function(double totalDeltaPx) onTrimEndUpdate;
  final VoidCallback onTrimEndEnd;
  // Move callbacks
  final VoidCallback onMoveStart;
  final Function(double totalDeltaSeconds) onMoveUpdate;
  final VoidCallback onMoveEnd;

  const _TextClipWidget({
    required this.clip,
    required this.isSelected,
    required this.pixelsPerSecond,
    required this.totalDuration,
    required this.onTap,
    required this.onTrimStartBegin,
    required this.onTrimStartUpdate,
    required this.onTrimStartEnd,
    required this.onTrimEndBegin,
    required this.onTrimEndUpdate,
    required this.onTrimEndEnd,
    required this.onMoveStart,
    required this.onMoveUpdate,
    required this.onMoveEnd,
  });

  @override
  State<_TextClipWidget> createState() => _TextClipWidgetState();
}

class _TextClipWidgetState extends State<_TextClipWidget> {
  bool _isDragging = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.purple.shade600,
        borderRadius: BorderRadius.circular(6),
        border: widget.isSelected
            ? Border.all(color: Colors.white, width: 2)
            : null,
        boxShadow: _isDragging
            ? [
                BoxShadow(
                  color: Colors.purple.withOpacity(0.5),
                  blurRadius: 8,
                  spreadRadius: 2,
                )
              ]
            : null,
      ),
      child: Row(
        children: [
          // LEFT TRIM HANDLE - adjusts startTime
          _TrimHandle(
            onDragStart: widget.onTrimStartBegin,
            onDragUpdate: widget.onTrimStartUpdate,
            onDragEnd: widget.onTrimStartEnd,
          ),

          // CENTER BODY - Long press + drag to move
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: widget.onTap,
              onLongPressStart: (_) {
                setState(() => _isDragging = true);
                widget.onMoveStart();
              },
              onLongPressMoveUpdate: (details) {
                if (!_isDragging) return;
                // Convert accumulated pixel delta to seconds
                final deltaSeconds = details.localOffsetFromOrigin.dx / widget.pixelsPerSecond;
                widget.onMoveUpdate(deltaSeconds);
              },
              onLongPressEnd: (_) {
                setState(() => _isDragging = false);
                widget.onMoveEnd();
              },
              onLongPressCancel: () {
                setState(() => _isDragging = false);
                widget.onMoveEnd();
              },
              child: Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  widget.clip.text,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),

          // RIGHT TRIM HANDLE - adjusts endTime
          _TrimHandle(
            onDragStart: widget.onTrimEndBegin,
            onDragUpdate: widget.onTrimEndUpdate,
            onDragEnd: widget.onTrimEndEnd,
          ),
        ],
      ),
    );
  }
}

/// Trim handle for adjusting start/end time (CapCut style)
/// Tracks cumulative delta from drag start for smooth, accurate trimming
class _TrimHandle extends StatefulWidget {
  final VoidCallback onDragStart;
  final Function(double totalDeltaPx) onDragUpdate;
  final VoidCallback onDragEnd;

  const _TrimHandle({
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
  });

  @override
  State<_TrimHandle> createState() => _TrimHandleState();
}

class _TrimHandleState extends State<_TrimHandle> {
  double _accumulatedDelta = 0;
  bool _isDragging = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragStart: (details) {
        _accumulatedDelta = 0;
        _isDragging = true;
        widget.onDragStart();
      },
      onHorizontalDragUpdate: (details) {
        if (!_isDragging) return;
        _accumulatedDelta += details.delta.dx;
        widget.onDragUpdate(_accumulatedDelta);
      },
      onHorizontalDragEnd: (details) {
        _isDragging = false;
        _accumulatedDelta = 0;
        widget.onDragEnd();
      },
      onHorizontalDragCancel: () {
        _isDragging = false;
        _accumulatedDelta = 0;
        widget.onDragEnd();
      },
      child: Container(
        width: 14,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: _isDragging ? Colors.white24 : Colors.black26,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(
            color: Colors.white70,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }
}
